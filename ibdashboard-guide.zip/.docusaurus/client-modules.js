export default [
  require("C:\\workspace\\softin\\ibdashboard-guide\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\workspace\\softin\\ibdashboard-guide\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\workspace\\softin\\ibdashboard-guide\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\workspace\\softin\\ibdashboard-guide\\src\\css\\custom.css"),
];
