import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', '5ff'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', '5ba'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', 'a2b'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', 'c3c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', '156'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '88c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '000'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '3d7'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '69d'),
    routes: [
      {
        path: '/docs',
        component: ComponentCreator('/docs', '8aa'),
        routes: [
          {
            path: '/docs',
            component: ComponentCreator('/docs', '40f'),
            routes: [
              {
                path: '/docs/가이드/대시보드/속성/cellHeight',
                component: ComponentCreator('/docs/가이드/대시보드/속성/cellHeight', 'e92'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/children',
                component: ComponentCreator('/docs/가이드/대시보드/속성/children', '960'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/column',
                component: ComponentCreator('/docs/가이드/대시보드/속성/column', 'a6c'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/disableDrag',
                component: ComponentCreator('/docs/가이드/대시보드/속성/disableDrag', '3eb'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/disableResize',
                component: ComponentCreator('/docs/가이드/대시보드/속성/disableResize', '561'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/float',
                component: ComponentCreator('/docs/가이드/대시보드/속성/float', 'a2a'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/level',
                component: ComponentCreator('/docs/가이드/대시보드/속성/level', '6bc'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/margin',
                component: ComponentCreator('/docs/가이드/대시보드/속성/margin', '82b'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/maxRow',
                component: ComponentCreator('/docs/가이드/대시보드/속성/maxRow', '803'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/속성/minRow',
                component: ComponentCreator('/docs/가이드/대시보드/속성/minRow', 'cec'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/API/addWidget',
                component: ComponentCreator('/docs/가이드/대시보드/API/addWidget', '86c'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/API/getWidget',
                component: ComponentCreator('/docs/가이드/대시보드/API/getWidget', '89d'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/API/removeWidget',
                component: ComponentCreator('/docs/가이드/대시보드/API/removeWidget', 'e6d'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/API/selectWidget',
                component: ComponentCreator('/docs/가이드/대시보드/API/selectWidget', 'e32'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/API/serialize',
                component: ComponentCreator('/docs/가이드/대시보드/API/serialize', 'b4d'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/API/updateWidget',
                component: ComponentCreator('/docs/가이드/대시보드/API/updateWidget', '188'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/Static API/create',
                component: ComponentCreator('/docs/가이드/대시보드/Static API/create', 'a32'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/Static API/deserialize',
                component: ComponentCreator('/docs/가이드/대시보드/Static API/deserialize', '45c'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/Static API/destroy',
                component: ComponentCreator('/docs/가이드/대시보드/Static API/destroy', '1c1'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/대시보드/Static API/get',
                component: ComponentCreator('/docs/가이드/대시보드/Static API/get', 'b4a'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/맵/속성/map',
                component: ComponentCreator('/docs/가이드/맵/속성/map', 'f2b'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/맵/속성/point',
                component: ComponentCreator('/docs/가이드/맵/속성/point', 'ab3'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/맵/속성/subtitle',
                component: ComponentCreator('/docs/가이드/맵/속성/subtitle', '271'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/맵/속성/theme',
                component: ComponentCreator('/docs/가이드/맵/속성/theme', 'f18'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/맵/속성/title',
                component: ComponentCreator('/docs/가이드/맵/속성/title', '5f5'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/맵/DataSet 가이드',
                component: ComponentCreator('/docs/가이드/맵/DataSet 가이드', 'a02'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/CanSort',
                component: ComponentCreator('/docs/가이드/시트/속성/CanSort', '437'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/CustomScroll',
                component: ComponentCreator('/docs/가이드/시트/속성/CustomScroll', 'd0c'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/Data Merge',
                component: ComponentCreator('/docs/가이드/시트/속성/Data Merge', 'ac5'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/Filter Dialog',
                component: ComponentCreator('/docs/가이드/시트/속성/Filter Dialog', 'e49'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/Filter Row',
                component: ComponentCreator('/docs/가이드/시트/속성/Filter Row', '892'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/RowMinHeight',
                component: ComponentCreator('/docs/가이드/시트/속성/RowMinHeight', '3a8'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/속성/Theme',
                component: ComponentCreator('/docs/가이드/시트/속성/Theme', 'fef'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/시트/DataSet 가이드',
                component: ComponentCreator('/docs/가이드/시트/DataSet 가이드', '38d'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/이미지/URL 가이드',
                component: ComponentCreator('/docs/가이드/이미지/URL 가이드', 'f0e'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/legend',
                component: ComponentCreator('/docs/가이드/차트/속성/legend', 'e01'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/plotOption bar',
                component: ComponentCreator('/docs/가이드/차트/속성/plotOption bar', 'f23'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/plotOption Line',
                component: ComponentCreator('/docs/가이드/차트/속성/plotOption Line', '55f'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/plotOption Pie',
                component: ComponentCreator('/docs/가이드/차트/속성/plotOption Pie', '3f8'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/subtitle',
                component: ComponentCreator('/docs/가이드/차트/속성/subtitle', 'ba7'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/theme',
                component: ComponentCreator('/docs/가이드/차트/속성/theme', '3f3'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/title',
                component: ComponentCreator('/docs/가이드/차트/속성/title', 'd26'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/xAxis',
                component: ComponentCreator('/docs/가이드/차트/속성/xAxis', '932'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/속성/yAxis',
                component: ComponentCreator('/docs/가이드/차트/속성/yAxis', '79c'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/차트/DataSet 가이드',
                component: ComponentCreator('/docs/가이드/차트/DataSet 가이드', 'e35'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/KPI/속성/data',
                component: ComponentCreator('/docs/가이드/KPI/속성/data', '6f7'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/KPI/속성/subtitle',
                component: ComponentCreator('/docs/가이드/KPI/속성/subtitle', '076'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/KPI/속성/title',
                component: ComponentCreator('/docs/가이드/KPI/속성/title', 'd2f'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/가이드/KPI/DataSet 가이드',
                component: ComponentCreator('/docs/가이드/KPI/DataSet 가이드', '048'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/시작하기/구성/데이터셋 구성',
                component: ComponentCreator('/docs/시작하기/구성/데이터셋 구성', 'e81'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/시작하기/구성/사이드바 구성',
                component: ComponentCreator('/docs/시작하기/구성/사이드바 구성', 'f71'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/시작하기/구성/위젯 생성',
                component: ComponentCreator('/docs/시작하기/구성/위젯 생성', '978'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/시작하기/구성/위젯 종류',
                component: ComponentCreator('/docs/시작하기/구성/위젯 종류', 'eec'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/시작하기/설치',
                component: ComponentCreator('/docs/시작하기/설치', '48e'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/시작하기/필수파일',
                component: ComponentCreator('/docs/시작하기/필수파일', '146'),
                exact: true,
                sidebar: "guideSidebar"
              },
              {
                path: '/docs/intro',
                component: ComponentCreator('/docs/intro', 'c2e'),
                exact: true,
                sidebar: "guideSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', 'e5f'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
